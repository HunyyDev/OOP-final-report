#pragma once

class ChessMan;

class Board
{
public:
	ChessMan* a[10][9];
	Board();
		
	//friend void KhoiTao(Player&, Player&, Board);
};