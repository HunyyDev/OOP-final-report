#include "CSoldiers.h"
#include <iostream>

using namespace std;

Soldiers::Soldiers()
{
}

Soldiers::Soldiers(int c)
{
	Color = c;
}

Soldiers::Soldiers(int a, int b)
{
	x = a;
	y = b;
	if (x >= 0 && x <= 4)
		Color = 0;
	if (x >= 5 && x <= 9) {
		Color = 1;
	}
}

bool Soldiers::check(int xx, int yy, Board b)
{
	if (xx < 0 || xx> 8 || yy < 0 || yy > 9)
		return false;
	if (Col() == 0) {
		if (x < 5)
			if (!(xx == (x + 1) && yy == y))
				return false;
		if (x >= 5)
			if (!((xx == (x + 1) && yy == y) || (yy == y && abs(xx - x) == 1)))
				return false;
	}
	else
	{
		if (x >= 5)
			if (!(xx == (x + 1) && yy == y))
				return false;
		if (x < 5)
			if (!((xx == (x + 1) && yy == y) || (yy == y && abs(xx - x) == 1)))
				return false;
	}
	if (b.a[xx][yy] != NULL && b.a[xx][yy]->Col() == Color)
		return false;
	return true;
}

void Soldiers::move(Board b)
{
	int xx, yy;
	cout << "Enter destination (Soldiers):";
	cin >> xx >> yy;
	while (check(xx, yy, b) == false) {
		cout << "Invalid! Again:";
		cin >> xx >> yy;
	}

	delete b.a[xx][yy];
	b.a[xx][yy] = b.a[x][y];
	b.a[x][y] = NULL;

	x = xx;
	y = yy;
}