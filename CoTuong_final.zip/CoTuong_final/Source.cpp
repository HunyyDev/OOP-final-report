﻿#include <iostream>
#include "CPlayer.h"
#include "CBoard.h"

using namespace std;

int main()
{
	Player A, B;
	Board C;
	KhoiTao(A, B, C);
	return 0;
}