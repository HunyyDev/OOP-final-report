#pragma once
#include"CBoard.h"

class ChessMan
{
protected:
	int x, y;
	int Color;
	int dead = 0;
public:
	int isDead();
	void die();
	int Col();
	virtual void move();
	virtual bool check(Board b);
};