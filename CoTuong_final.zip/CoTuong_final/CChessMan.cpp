#include "CChessMan.h"

int ChessMan::isDead()
{
	return dead;
}

void ChessMan::die()
{
	dead = 1;
}

int ChessMan::Col()
{
	return Color;
}

void ChessMan::move()
{
	return;
}

bool ChessMan::check(Board b)
{
	return true;
}
