#include "CKing.h"
#include<iostream>

using namespace std;

King::King()
{
}

King::King(int c)
{
	Color = c;
}

King::King(int a, int b)
{
	x = a;
	y = b;
	if (x >= 0 && x <= 4)
		Color = 0;
	if (x >= 5 && x <= 9) {
		Color = 1;
	}
}

bool King::check(int xx, int yy, Board b)
{
	if (!((abs(xx - x) == 1 && yy == y) || (abs(yy - y) == 1 && xx == x)))
		return false;
	if (xx > 5 || xx < 3)
		return false;
	if (Color == 0) {
		if (yy < 0 || yy>2)
			return false;
	}
	else if (Color == 1) {
		if (yy > 9 || yy < 7)
			return false;
	}
	if (b.a[xx][yy] != NULL && b.a[xx][yy]->Col() == Color)
		return false;
	return true;
}

void King::move(Board b)
{
	int xx, yy;
	cout << "Enter destination (General):";
	cin >> xx >> yy;
	while (check(xx, yy, b) == false) {
		cout << "Invalid! Again:";
		cin >> xx >> yy;
	}
	delete b.a[xx][yy];
	b.a[xx][yy] = b.a[x][y];
	b.a[x][y] = NULL;
	x = xx;
	y = yy;
}